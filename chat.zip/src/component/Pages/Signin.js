import React from 'react';
import { Link } from 'react-router-dom';
import { useState } from "react";
import axios from "axios";

const Signin = () => {

    const [email, setEmail] = useState("");
    const [password,setPassword] = useState("");

    const handleSubmit = e => {
        // Prevent the default submit and page reload
        e.preventDefault()
    
        // Handle validations
        axios
          .post("http://localhost/Mylearning/new/api/login", { email, password })
          .then(response => {
            console.log('success')
            if(response.status==200) {
                console.log('login successfully')
            }
            // Handle response
          })
        }
    
  return (
    <div className="container">
    <div className="row align-items-center justify-content-center min-vh-100 gx-0">

        <div className="col-12 col-md-5 col-lg-4">
            <div className="card card-shadow border-0">
                <div className="card-body">
                    <div className="row g-6">
                        <form action=''  method="post" onSubmit={handleSubmit} >
                        <div className="col-12">
                            <div className="text-center">
                                <h3 className="fw-bold mb-2">Sign In</h3>
                                <p>Login to your account</p>
                            </div>
                        </div>

                        <div className="col-12 mb-3">
                            <div className="form-floating">
                                <input type="email" className="form-control" id="signin-email" placeholder="Email"
                                 onChange={(e)=>setEmail(e.target.value)}
                                  value={email} autoComplete='off'/>
                                <label htmlFor="signin-email">Email</label>
                            </div>
                        </div>

                        <div className="col-12 mb-3">
                            <div className="form-floating">
                                <input type="password" className="form-control" id="signin-password" placeholder="Password"
                                 onChange= {(e) =>setPassword(e.target.value)} 
                                 value={password} />
                                <label htmlFor="signin-password">Password</label>
                            </div>
                        </div>

                        <div className="col-12">
                            <button className="btn btn-block btn-lg btn-primary w-100" type="submit">Sign In</button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>

            
            <div className="text-center mt-8">
                <p>Don't have an account yet? <Link to = "/signup"> Sign up </Link> </p>
                <p><a >Forgot Password?</a></p>
            </div>
        </div>
    </div> 
</div>
  )
}

export default Signin